import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { AppComponent } from './app.component';
import { HeaderComponent } from './components/header/header.component';
import { AboutComponent } from './components/about/about.component';
import { ProjectsComponent } from './components/projects/projects.component';
import { SocialsComponent } from './components/socials/socials.component';
import { FormsModule } from '@angular/forms';
import { provideHttpClient, withInterceptorsFromDi } from '@angular/common/http';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import { MatIconModule } from '@angular/material/icon';

@NgModule({ declarations: [
        AppComponent,
        HeaderComponent,
        AboutComponent,
        ProjectsComponent,
        SocialsComponent,
    ],
    bootstrap: [AppComponent], 
    imports: [BrowserModule, FormsModule, MatSlideToggleModule, MatIconModule], 
    providers: [provideHttpClient(withInterceptorsFromDi())] })
export class AppModule {}
